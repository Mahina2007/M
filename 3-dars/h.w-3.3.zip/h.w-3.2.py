username = input("username: ")
password = input("password: ")

if username == "none1212" and password == "pass1234":
    print("Welcome!")
else:
    print("Incorrect username/password")



