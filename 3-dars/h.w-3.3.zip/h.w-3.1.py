temperature = int(input("What's the temperature: "))

if temperature < 0:
    print("havo juda sovuq, issiq kiyining!")
elif 0 <= temperature <= 20:
    print("havo salqin, kurtka kiying!")
else :
    print("havo issiq, yengil kiyinishingiz mumkin.")
    



