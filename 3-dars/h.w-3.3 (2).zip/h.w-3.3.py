a = int(input("Insert a number: "))

if a == 1:
    print("It's Monday")
elif a == 2:
    print("It's Tuesday")
elif a == 3:
    print("It's Wednesday")
elif a == 4:
    print("It's Thursday")
elif a == 5:
    print("It's Friday")
elif a == 6:
    print("It's Saturday")
elif a == 7:
    print("It's Sunday")
else:
    print("there's no that kind of day")
    



